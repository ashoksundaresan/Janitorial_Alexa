<?php
//if (!isset($_POST['response']) ) {
//$file = 'alexalol.txt';
//$current = $_POST["email"];
//file_put_contents($file, $current);
//echo "hit";
$email = $_POST["email"];
$query = $_POST["query"];
//$address='172.20.10.2';
$address="localhost";
$port=2003;
//echo "Testing Client Server\n";
if(! $socket = socket_create(AF_INET, SOCK_STREAM, getprotobyname('tcp'))){            showError("socket create");
        };

socket_connect($socket, $address, $port);

$myObj->type =1;
                $myObj->message = $query;
                $myObj->alexaemail = $email;
                $myJSON = json_encode($myObj);
                $msg = "$myJSON" . "-";
        socket_write($socket, $msg, strlen($msg));
        $result = socket_read ($socket, 2003) or die("Could not read server response\n");
        socket_close($socket);
//echo $msg;
//}
//else {
//$fh = fopen('alexa.txt', 'w'); 

echo $result;

?>
