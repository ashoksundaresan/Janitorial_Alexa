<? php
echo "sure fucker";
echo $_POST["email"];
?>
