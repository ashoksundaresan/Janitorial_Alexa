<?php
	echo var_dump($_POST);
	echo "query " . $_POST["email"];
?>
